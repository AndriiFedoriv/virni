Hosting link: https://koldovsky.github.io/online-shop/

To run:
1. Install dependencies: `npm i`
2. Run: `node server.js`
